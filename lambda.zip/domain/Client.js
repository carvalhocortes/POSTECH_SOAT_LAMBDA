"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Client = void 0;
var Client = /** @class */ (function () {
    function Client(cpf) {
        this.cpf = cpf;
        if (!/^\d{11}$/.test(cpf))
            throw new Error('CPF inválido');
    }
    return Client;
}());
exports.Client = Client;
