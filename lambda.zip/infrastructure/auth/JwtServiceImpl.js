"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtServiceImpl = void 0;
var jwt = require("jsonwebtoken");
var JwtServiceImpl = /** @class */ (function () {
    function JwtServiceImpl(secret) {
        this.secret = secret;
    }
    JwtServiceImpl.prototype.sign = function (_a) {
        var cpf = _a.cpf;
        return jwt.sign({ cpf: cpf }, this.secret, { expiresIn: "15m" });
    };
    return JwtServiceImpl;
}());
exports.JwtServiceImpl = JwtServiceImpl;
